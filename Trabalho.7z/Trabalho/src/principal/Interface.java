package principal;

import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Frame;
import java.awt.Toolkit;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import java.awt.Color;
import javax.swing.JLayeredPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextField;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Interface extends JFrame {

	private JPanel contentPane;
	private JLayeredPane layeredPane;
	private JPanel verTransporte;
	private JPanel adicionar;
	private JPanel editar;
	private JPanel apagar;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Interface frame = new Interface();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public void Switch_screen(JPanel p) {
		layeredPane.removeAll();
		layeredPane.add(p);
		layeredPane.repaint();
		layeredPane.revalidate();
		
	}
	/**
	 * Create the frame.
	 */
	public Interface() {
		
		int width = (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth();
		int height = (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight();
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(0, 0, (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(), (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight());
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));

		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		JTabbedPane tabbedPane = new JTabbedPane(JTabbedPane.TOP);
		tabbedPane.setBounds(0, 0, (int)Toolkit.getDefaultToolkit().getScreenSize().getWidth(), (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight());
		contentPane.add(tabbedPane);
		
		JPanel home = new JPanel();
		home.setBackground(new Color(0, 37, 86));
		tabbedPane.addTab("Home", null, home, null);
		home.setLayout(null);
		
		JLabel lblNewLabel = new JLabel("New label");
		lblNewLabel.setIcon(new ImageIcon(Interface.class.getResource("/img/Logo.png")));
		lblNewLabel.setBounds(width/2 - 250, height/2 - 250, 500, 500);
		home.add(lblNewLabel);
		
		JPanel transporte = new JPanel();
		transporte.setBackground(new Color(0, 37, 86));
		tabbedPane.addTab("Transporte", null, transporte, null);
		transporte.setLayout(null);
		
		layeredPane = new JLayeredPane();
		layeredPane.setBounds(0, 685, 962, -684);
		transporte.add(layeredPane);
		
		verTransporte = new JPanel();
		verTransporte.setBackground(new Color(0, 37, 86));
		verTransporte.setBounds(0, -687, 962, 697);
		layeredPane.add(verTransporte);
		
		adicionar = new JPanel();
		adicionar.setBackground(new Color(0, 37, 86));
		adicionar.setBounds(0, -682, 962, 692);
		layeredPane.add(adicionar);
		
		editar = new JPanel();
		editar.setBackground(new Color(0, 37, 86));
		editar.setBounds(0, -687, 962, 697);
		layeredPane.add(editar);
		
		apagar = new JPanel();
		apagar.setBackground(new Color(0, 37, 86));
		apagar.setBounds(0, -687, 932, 697);
		layeredPane.add(apagar);
		
		JButton addTranporte = new JButton("Adicionar");
		addTranporte.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Switch_screen(adicionar);
			}
		});
		
		addTranporte.setBounds((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2 -150, (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight()/2 -100, 100, 40);
		transporte.add(addTranporte);
		
		JButton delTransporte = new JButton("Apagar");
		delTransporte.setBounds((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2 -150, (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight()/2 + 50, 100, 40);
		transporte.add(delTransporte);
		
		JButton updTransporte = new JButton("Editar");
		updTransporte.setBounds((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2 + 50, (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight()/2 - 100, 100, 40);
		transporte.add(updTransporte);
		
		JButton lisTransporte = new JButton("Ver");
		lisTransporte.setBounds((int)Toolkit.getDefaultToolkit().getScreenSize().getWidth()/2 + 50, (int) Toolkit.getDefaultToolkit().getScreenSize().getHeight()/2 + 50, 100, 40);
		transporte.add(lisTransporte);
		
		JPanel destino = new JPanel();
		destino.setBackground(new Color(0, 37, 86));
		tabbedPane.addTab("Destino", null, destino, null);
		
		JPanel viagem = new JPanel();
		viagem.setBackground(new Color(0, 37, 86));
		tabbedPane.addTab("Viagem", null, viagem, null);
		
		JPanel fuso = new JPanel();
		fuso.setBackground(new Color(0, 37, 86));
		tabbedPane.addTab("Fuso Hor�rio", null, fuso, null);
		
		JPanel turistico = new JPanel();
		turistico.setBackground(new Color(0, 37, 86));
		tabbedPane.addTab("Ponto Tur�stico", null, turistico, null);
		
		
		
	}
	
}

		
		
		


		
		

	
	
	
